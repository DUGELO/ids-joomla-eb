<?php
defined('_JEXEC') or die;

$app   = JFactory::getApplication();
$menu  = $app->getMenu();
$active = $menu->getActive();

// Só exibe na página inicial
if (!$active || !$active->home) {
    return;
}

$imagem       = $params->get('imagem');
$temporizador = $params->get('temporizador');
$segundos     = (int) $params->get('segundos');
$texto        = $params->get('popuptext');
?>

<div class="overlay" id="div-pop">
    <div class="popup-box">
        <button id="close-btn" class="close-btn">
            Fechar <?php if ($temporizador && $segundos): ?>(<span id="counter"><?php echo $segundos; ?></span>)<?php endif; ?>
        </button>

        <div class="text-pop">
            <?php if ($imagem): ?>
                <img class="img-pop" id="img-pop" src="<?php echo htmlspecialchars($imagem, ENT_QUOTES); ?>" onerror="this.style.display='none';">
            <?php endif; ?>

            <?php if ($texto): ?>
                <?php echo $texto; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.overlay {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.7);
    position: fixed;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    z-index: 9999;
}
.popup-box {
    background-color: white;
    width: 50%;
    height: 80%;
    max-height: 80%;
    padding: 20px;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    overflow-y: auto;
}
@media (max-width: 768px) {
    .popup-box { width: 80%; }
}
.img-pop {
    cursor: default;
    max-width: 90%;
    max-height: 90%;
    object-fit: contain;
}
.text-pop {
    width: 100%;
    max-height: 100%;
    overflow-y: auto;
    text-align: center;
}
.close-btn {
    align-self: flex-end;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    background-color: red;
    color: white;
    cursor: pointer;
    border-radius: 5px;
    margin-bottom: 10px;
}
</style>

<script>
function removePopUp() {
    document.getElementById('div-pop').style.display = 'none';
}

document.addEventListener("DOMContentLoaded", function() {
    const popup = document.getElementById('div-pop');
    const closeBtn = document.getElementById('close-btn');
    const popupBox = document.querySelector('.popup-box');
    let counter = <?= (int) $segundos; ?>;
    const counterElement = document.getElementById('counter');

    // Fecha ao clicar no botão
    closeBtn.addEventListener('click', removePopUp);

    // Fecha ao clicar fora do conteúdo (no fundo escuro)
    popup.addEventListener('click', function(e) {
        // Só fecha se o clique for no overlay, não dentro do conteúdo
        if (!popupBox.contains(e.target)) {
            removePopUp();
        }
    });

    // Temporizador automático, se configurado
    if (counter > 0) {
        const interval = setInterval(() => {
            counter--;
            counterElement.textContent = counter;
            if (counter <= 0) {
                clearInterval(interval);
                removePopUp();
            }
        }, 1000);
    }
});
</script>
